from pyparsing import ZeroOrMore, Suppress, nestedExpr, OneOrMore, Keyword, Literal, Word, alphas, alphanums, Optional, Group, ParseException, restOfLine, cppStyleComment
from jinja2 import Environment, FileSystemLoader, select_autoescape
import re, os
from typing import Dict, Sequence, Tuple
known_types = {"int64_t": 8, "uint64_t": 8, "int32_t": 4, "uint32_t": 4, "int16_t": 2, "uint16_t": 2, "int8_t": 1, "uint8_t": 1, "double64_t": 8, "float32_t": 4, 
               "bool_t": 1, "int64": 8, "uint64": 8, "int32": 4, "uint32": 4, "int16": 2, "uint16": 2, "int8": 1, "uint8": 1, "double64": 8, "float": 4, "bool": 1,
               'real_T': 32, 'boolean_T': 2, 'real32_T': 32}


def read_header_files(source_dir: str):
    text: str = ''
    for file in os.listdir(source_dir):
        if file.endswith('.h'):
            with open(source_dir + '/' + file, 'r') as f:
                text += f.read()
    return text


def read_header(text: str) -> Dict[str, list]:
    integer = Word("-"+alphanums)
    identifier      = Word(alphas+'_', alphanums+'_')()
    class_tkn_struct       = Keyword('typedef struct').suppress()
    class_tkn_enum  = Keyword('typedef enum').suppress()
    lbrace_tkn      = Literal('{').suppress()
    rbrace_tkn      = Literal('}').suppress()
    lsq_brace_tkn   = Literal('[').suppress()
    rsq_brace_tkn   = Literal(']').suppress()
    semicolon_tkn   = Literal(';').suppress()
    comma_tkn   = Literal(',').suppress()
    enumValue = Group(((identifier("type") + identifier("name")) | identifier("name")) + 
                      Optional(lsq_brace_tkn + integer("dimension") + rsq_brace_tkn) +  Optional("=" + integer("value")) + Optional(semicolon_tkn | comma_tkn))
    enumList = Group(OneOrMore(enumValue))

    class_block     = OneOrMore( 
                        Group(
                            (class_tkn_struct | class_tkn_enum) + 
                            lbrace_tkn + \
                            enumList("names") + \
                            rbrace_tkn + \
                            identifier("name") + \
                            semicolon_tkn \
                    ))
    class_block.ignore( '#' + restOfLine )
    class_block.ignore( '*' + restOfLine )
    class_block.ignore( '/*' + restOfLine )
    class_block.ignore( '*/' + restOfLine )
    class_block.ignore( '//' + restOfLine )
    class_block.ignore(cppStyleComment)
    comment = Suppress(nestedExpr("/*", "*/"))
    # class_block.setDebug(True)
    res = {}
    text = comment.transform_string(text)
    try:
        results = class_block.search_string(text)
        for group in results:
            for item in group:
                res[item.name] = {"children": {}}
                for i in item.names:
                    res[item.name]["children"][i["name"]] = {"datatype":i.get("type", ""), "name": i["name"], "size": 4, "dimension": i.get('dimension', '')}
    except ParseException as s:
        print("Syntax error:", s)
    except Exception as ex:
        print("errore", ex)
    return res


def generate_source_file(env:Environment, tmpl_name: str, data: Dict, output_file_path: str):
    ''' create the source file starting from a template and data to template '''
    try:
        tmpl = env.get_template(tmpl_name)
        file_content = tmpl.render(**data)
        with open(output_file_path, "w", encoding="utf-8") as f:
            f.write(file_content)
            f.close()
    except Exception as ex:
        print("generate_source_file", tmpl_name, ex, output_file_path)


def extract_nested_bus_signals(data: Dict, busName: str, nestedBusMsgsName: str, 
                               signals: Sequence[Dict], sizeBits: int) -> Tuple[Sequence[Dict], int]:
    struct: Dict = data[busName]['children']
    for busName, busData in struct.items():
        if busData['datatype'] and busData['datatype'] not in known_types:
            if not busData['dimension']:
                nestedBusMsgsName = nestedBusMsgsName + '.' +  busData['name'] if nestedBusMsgsName else busData['name']
                _, sizeBits =  extract_nested_bus_signals(data, busData['datatype'], nestedBusMsgsName, signals, sizeBits)
                nestedBusMsgsName = '.'.join(nestedBusMsgsName.split('.')[:-1]) ### move-one-level-up
            else:
                dimensions = int(busData['dimension'])
                for dim in range(1,  dimensions+1):
                    nestedBusMsgsName = nestedBusMsgsName + '.' +  busData['name'] + '_' + str(dim) if nestedBusMsgsName else busData['name'] + '_' + str(dim)
                    _, sizeBits =  extract_nested_bus_signals(data, busData['datatype'], nestedBusMsgsName, signals, sizeBits)
                    nestedBusMsgsName = '.'.join(nestedBusMsgsName.split('.')[:-1]) ### move-one-level-up
        else:
            if not busData['dimension']:
                sig = dict()
                sig['name'] = nestedBusMsgsName + '.' +  busData['name'] if nestedBusMsgsName else busData['name']
                sig['base_name'] = busData['name']
                sig['type'] = 'f32'
                sig['length'] = int(32)
                sizeBits += 32
                signals.append(sig)
            else:
                dimensions = int(busData['dimension'])
                for dim in range(1, dimensions+1):
                    sig = dict()
                    sig['name'] = nestedBusMsgsName + '.' +  busData['name'] + '_' + str(dim) if nestedBusMsgsName else busData['name'] + '_' + str(dim) 
                    sig['base_name'] =  busData['name'] + '_' + str(dim)
                    sig['type'] = 'f32'
                    sig['length'] = int(32)
                    sizeBits += 32
                    signals.append(sig)
            
    return signals, sizeBits


def extract_nested_bus_messages(data: Dict, busName: str) -> Tuple[Sequence[Dict], int]:
    dataitem = dict()
    dataitem['link_name'] = busName
    dataitem['Messages'] = dict()

    sizeBits = 0
    struct = data[busName]['children']
    for busName, busData in struct.items():
        dataitem['Messages'][busName] = {}
        if busData['datatype'] and busData['datatype'] not in known_types:
            if not busData['dimension']:
                dataitem['Messages'][busName] = {'Signals': []}
                signalStruct, sizeBits = extract_nested_bus_signals(data, busData['datatype'], '', [], sizeBits)
                dataitem['Messages'][busName]['Signals'] = signalStruct
            else:
                raise Exception("Conidition not handled.")
        else:
            if not busData['dimension']:
                sig: dict = {}
                sig['name'] = busName
                sig['base_name'] = busName
                sig['type'] = 'f32'
                sig['length'] = int(32)
                sizeBits += int(32)
                dataitem['Messages'][busName] = {'Signals': [sig]}
            else:
                dimensions = int(busData['dimension'])
                dataitem['Messages'][busName] = {'Signals': []}
                for dim in range(1, dimensions+1):
                    sig: dict = {}
                    sig['name'] = busName + "_" + str(dim)
                    sig['base_name'] = busName + "_" + str(dim)
                    sig['type'] = 'f32'
                    sig['length'] = int(32)
                    sizeBits += int(32)
                    dataitem['Messages'][busName]['Signals'].append(sig)
    return dataitem, sizeBits

    


if __name__ == "__main__":
    text = read_header_files("input_file/FDM_ert_rtw/FDM_ert_rtw")
    res = read_header(text)
    env = Environment(extensions=["jinja2.ext.loopcontrols"], loader=FileSystemLoader(f"templates/xml"), autoescape=select_autoescape(["xml.j2"]))
    env.filters["regex_replace"] = lambda txt, search, replace: re.sub(search, replace, txt)

    root_struct_names = ['FDM_values_out_bus', 'FDM_events_out_bus', 'FDM_log_bus']
    
    for root_struct in root_struct_names:
        data, bit_link_length = extract_nested_bus_messages(res, root_struct)
        
        export_directory = "output"
        filename = root_struct + ".xml"
        tmpl_name = "_LNK_.xml.j2"
        no_padding = True
        output_file_path = os.path.join(export_directory, filename)
        generate_source_file(env, tmpl_name, {"bit_size": bit_link_length, "link_name": root_struct, "dataItem" : data, "no_padding": no_padding}, output_file_path)

        print("Run Successfull !")